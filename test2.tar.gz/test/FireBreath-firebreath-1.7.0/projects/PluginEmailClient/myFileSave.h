#pragma once
#include <gtk/gtk.h>
#include <iostream>

using namespace std;

class MyFileSave
{

public:
	MyFileSave(void) :
        myFileSaveWin(NULL)
        ,mySavePath("")
	{
        gtk_init(0,0);
        gdk_threads_init();
	}

	MyFileSave(int argc, char *argv[]) :
        myFileSaveWin(NULL)
        ,mySavePath("")
	{
	    gtk_init(&argc,&argv);
	    gdk_threads_init();
	}

	~MyFileSave(void){}

private:
	GtkWidget 	*myFileSaveWin;
	string 	mySavePath;

public:
	void SelectSavePath()
	{
		myFileSaveWin = gtk_file_chooser_dialog_new(	 "Save File",NULL
                                                                                                             , GTK_FILE_CHOOSER_ACTION_SAVE
                                                                                                             , GTK_STOCK_CANCEL
                                                                                                             , GTK_RESPONSE_CANCEL
                                                                                                             , GTK_STOCK_SAVE
                                                                                                             , GTK_RESPONSE_ACCEPT
                                                                                                             , NULL);

	  gtk_window_set_position(GTK_WINDOW(myFileSaveWin), GTK_WIN_POS_CENTER_ALWAYS);

        gdk_threads_enter();

		if(gtk_dialog_run(GTK_DIALOG(myFileSaveWin)) == GTK_RESPONSE_ACCEPT)
			SetSavePath();

		gtk_widget_destroy(myFileSaveWin);

		gdk_threads_leave();

		myFileSaveWin = NULL;
	}

	string GetSavePath()
	{
		return mySavePath;
	}

private:
	void SetSavePath()
	{
    		mySavePath = gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(myFileSaveWin));
	}
};


