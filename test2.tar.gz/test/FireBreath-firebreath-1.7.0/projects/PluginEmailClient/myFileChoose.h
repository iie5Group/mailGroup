#pragma once
#include <gtk/gtk.h>
#include <vector>
#include <iostream>

using namespace std;

class MyFileChoose
{

public:
	MyFileChoose(void) :
        myFileChooseWin(NULL)
	{
        gtk_init(0,0);
        gdk_threads_init();
	}

	MyFileChoose(int argc, char *argv[]) :
        myFileChooseWin(NULL)
	{
	    gtk_init(&argc,&argv);
	    gdk_threads_init();
	}

	~MyFileChoose(void){}

private:
	GtkWidget 		*myFileChooseWin;
	vector<string> 	myFilePathList;

public:
	void SelectFiles()
	{
		myFilePathList.clear();

        	myFileChooseWin = gtk_file_chooser_dialog_new(	 "SelectFile"
                                                                     ,NULL
                                                                     ,GTK_FILE_CHOOSER_ACTION_OPEN
                                                                     ,GTK_STOCK_CANCEL
                                                                     ,GTK_RESPONSE_CANCEL
                                                                     ,GTK_STOCK_OK
                                                                     ,GTK_RESPONSE_ACCEPT
                                                                     ,NULL);

        	gtk_file_chooser_set_select_multiple( GTK_FILE_CHOOSER( myFileChooseWin ), TRUE );

        	gtk_window_set_position(GTK_WINDOW(myFileChooseWin), GTK_WIN_POS_CENTER_ALWAYS);

        gdk_threads_enter();
		if( gtk_dialog_run( GTK_DIALOG( myFileChooseWin ) ) == GTK_RESPONSE_ACCEPT )
			SetFilesPath();

		gtk_widget_destroy(myFileChooseWin);

		gdk_threads_leave();

		myFileChooseWin = NULL;
	}

	vector<string> GetFilesPathList()
	{
        return myFilePathList;
	}

private:
	void SetFilesPath()
	{
		string pFilePathTemp;
        	GSList *pFilePaths;

        	pFilePaths = gtk_file_chooser_get_filenames(GTK_FILE_CHOOSER(myFileChooseWin));

    	  	myFilePathList.clear();

        	do
        	{
                pFilePathTemp = (gchar*)pFilePaths->data;
                myFilePathList.push_back(pFilePathTemp);
                pFilePaths = pFilePaths->next;

        	}while(pFilePaths);
	}
};

